"use client";

import { useState } from "react";
import api from "@/lib/axios";
import Link from "next/link";

export default function RegisterPage() {
  const [form, setForm] = useState({ name: "", email: "", password: "" });
  const [message, setMessage] = useState("");

  const handleChange = (e: React.ChangeEvent<HTMLInputElement>) => {
    setForm({ ...form, [e.target.name]: e.target.value });
  };

  const handleRegister = async (e: React.FormEvent) => {
    e.preventDefault();
    try {
      const res = await api.post("/auth/register", form);
      setMessage(res.data.message);
      window.location.href = "/login";
    } catch (error: any) {
      setMessage(error?.response?.data?.message || "Register failed");
    }
  };

  return (
    <div className="page-center">
      <div className="card" style={{ width: "100%", maxWidth: 420 }}>
        <h1 style={{ marginBottom: 20 }}>Register</h1>

        <form onSubmit={handleRegister} style={{ display: "grid", gap: 14 }}>
          <input className="input" type="text" name="name" placeholder="Name" onChange={handleChange} />
          <input className="input" type="email" name="email" placeholder="Email" onChange={handleChange} />
          <input className="input" type="password" name="password" placeholder="Password" onChange={handleChange} />
          <button className="btn" type="submit">
            Create Account
          </button>
        </form>

        {message && <p style={{ marginTop: 14 }}>{message}</p>}

        <p style={{ marginTop: 14 }}>
          Already have an account? <Link href="/login">Login</Link>
        </p>
      </div>
    </div>
  );
}