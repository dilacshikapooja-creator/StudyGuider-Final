"use client";

import { useState } from "react";
import api from "@/lib/axios";

export default function UploadNotesPage() {
  const [title, setTitle] = useState("");
  const [subject, setSubject] = useState("");
  const [file, setFile] = useState<File | null>(null);
  const [message, setMessage] = useState("");

  const handleUpload = async (e: React.FormEvent) => {
    e.preventDefault();

    if (!file) {
      setMessage("Please choose a file");
      return;
    }

    try {
      const token = localStorage.getItem("token");
      const formData = new FormData();
      formData.append("title", title);
      formData.append("subject", subject);
      formData.append("file", file);

      const res = await api.post("/notes/upload", formData, {
        headers: {
          Authorization: `Bearer ${token}`,
        },
      });

      setMessage(res.data.message);
    } catch (error: any) {
      setMessage(error?.response?.data?.message || "Upload failed");
    }
  };

  return (
    <div className="container" style={{ padding: "40px 0" }}>
      <div className="card" style={{ maxWidth: 600 }}>
        <h1 style={{ marginBottom: 20 }}>Upload Notes</h1>

        <form onSubmit={handleUpload} style={{ display: "grid", gap: 14 }}>
          <input
            className="input"
            type="text"
            placeholder="Title"
            value={title}
            onChange={(e) => setTitle(e.target.value)}
          />
          <input
            className="input"
            type="text"
            placeholder="Subject"
            value={subject}
            onChange={(e) => setSubject(e.target.value)}
          />
          <input
            className="input"
            type="file"
            onChange={(e) => setFile(e.target.files?.[0] || null)}
          />
          <button className="btn" type="submit">
            Upload
          </button>
        </form>

        {message && <p style={{ marginTop: 14 }}>{message}</p>}
      </div>
    </div>
  );
}