import Link from "next/link";
import styles from "./page.module.scss";

export default function HomePage() {
  return (
    <main className={styles.home}>
      <nav className={styles.nav}>
        <div className="container">
          <div className={styles.navInner}>
            <h2>Study Guider</h2>
            <div className={styles.links}>
              <Link href="/login">Login</Link>
              <Link href="/register" className={styles.primary}>
                Get Started
              </Link>
            </div>
          </div>
        </div>
      </nav>

      <section className={styles.hero}>
        <div className="container">
          <div className={styles.heroGrid}>
            <div>
              <p className={styles.badge}>AI Powered Study App</p>
              <h1>Turn notes into summaries, quizzes, flashcards and mind maps</h1>
              <p>
                Study Guider helps students upload notes and learn faster with AI-generated
                study tools.
              </p>
              <div className={styles.actions}>
                <Link href="/register" className={styles.primaryBtn}>
                  Start Free
                </Link>
                <Link href="/login" className={styles.secondaryBtn}>
                  Login
                </Link>
              </div>
            </div>

            <div className={styles.preview}>
              <div className="card">
                <h3>Smart Study Dashboard</h3>
                <ul>
                  <li>Notes Uploaded: 12</li>
                  <li>Quizzes Completed: 8</li>
                  <li>Average Score: 84%</li>
                  <li>Flashcards Ready: 52</li>
                </ul>
              </div>
            </div>
          </div>
        </div>
      </section>

      <section className={styles.features}>
        <div className="container">
          <h2 className="section-title">Features</h2>
          <div className={styles.featureGrid}>
            <div className="card">
              <h3>Upload Notes</h3>
              <p>Upload PDF or text notes easily.</p>
            </div>
            <div className="card">
              <h3>AI Summary</h3>
              <p>Get short and simple summaries.</p>
            </div>
            <div className="card">
              <h3>Quiz Generator</h3>
              <p>Practice using AI generated questions.</p>
            </div>
            <div className="card">
              <h3>Mind Map</h3>
              <p>Understand topics visually.</p>
            </div>
          </div>
        </div>
      </section>
    </main>
  );
}