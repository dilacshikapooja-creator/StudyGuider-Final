"use client";

import { useState } from "react";
import api from "@/lib/axios";
import Link from "next/link";

export default function LoginPage() {
  const [form, setForm] = useState({ email: "", password: "" });
  const [message, setMessage] = useState("");

  const handleChange = (e: React.ChangeEvent<HTMLInputElement>) => {
    setForm({ ...form, [e.target.name]: e.target.value });
  };

  const handleLogin = async (e: React.FormEvent) => {
    e.preventDefault();
    try {
      const res = await api.post("/auth/login", form);
      localStorage.setItem("token", res.data.token);
      setMessage("Login success");
      window.location.href = "/dashboard";
    } catch (error: any) {
      setMessage(error?.response?.data?.message || "Login failed");
    }
  };

  return (
    <div className="page-center">
      <div className="card" style={{ width: "100%", maxWidth: 420 }}>
        <h1 style={{ marginBottom: 20 }}>Login</h1>

        <form onSubmit={handleLogin} style={{ display: "grid", gap: 14 }}>
          <input
            className="input"
            type="email"
            name="email"
            placeholder="Email"
            onChange={handleChange}
          />
          <input
            className="input"
            type="password"
            name="password"
            placeholder="Password"
            onChange={handleChange}
          />
          <button className="btn" type="submit">
            Login
          </button>
        </form>

        {message && <p style={{ marginTop: 14 }}>{message}</p>}

        <p style={{ marginTop: 14 }}>
          Don&apos;t have an account? <Link href="/register">Register</Link>
        </p>
      </div>
    </div>
  );
}