import Link from "next/link";

export default function DashboardPage() {
  return (
    <div className="container" style={{ padding: "40px 0" }}>
      <h1 style={{ marginBottom: 20 }}>Dashboard</h1>

      <div
        style={{
          display: "grid",
          gridTemplateColumns: "repeat(auto-fit,minmax(220px,1fr))",
          gap: 16,
          marginBottom: 24,
        }}
      >
        <div className="card">
          <h3>Total Notes</h3>
          <p>12</p>
        </div>
        <div className="card">
          <h3>Quiz Attempts</h3>
          <p>8</p>
        </div>
        <div className="card">
          <h3>Average Score</h3>
          <p>84%</p>
        </div>
      </div>

      <div style={{ display: "flex", gap: 12, flexWrap: "wrap" }}>
        <Link href="/upload-notes" className="btn">
          Upload Notes
        </Link>
        <Link href="/" className="btn btn-secondary">
          Back Home
        </Link>
      </div>
    </div>
  );
}